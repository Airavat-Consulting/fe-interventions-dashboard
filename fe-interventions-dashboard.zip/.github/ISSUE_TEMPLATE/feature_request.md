---
name: Feature request
about: Suggest an idea or enhancement
labels: [feat]
---

**Description**

A clear and concise description of the feature you are proposing.

**Acceptance Criteria**

- [ ] Describe what success looks like
- [ ] Include any UI/UX considerations
- [ ] Identify affected models or services

**Additional context**

Add any other context or screenshots about the feature request here.