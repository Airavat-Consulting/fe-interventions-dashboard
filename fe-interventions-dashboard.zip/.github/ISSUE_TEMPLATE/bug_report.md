---
name: Bug report
about: Report a bug or unexpected behaviour
labels: [bug]
---

**Describe the bug**

A clear and concise description of what the bug is.

**To Reproduce**

Steps to reproduce the behaviour:
1. Go to '...'
2. Click on '...'
3. See error

**Expected behaviour**

What you expected to happen instead.

**Screenshots**

If applicable, add screenshots to help explain your problem.